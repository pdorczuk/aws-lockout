var aws = require('aws-sdk');
var iam = new aws.IAM();

// ARN of the policy that denies all IAM access
var policyArn = 'arn:aws:iam::307005721529:policy/DenyIAMAccess';

// Name of the group for admin users
var adminGroupName = 'admins';

exports.handler = function(event, context) {
     // Print the incoming Amazon CloudWatch Events event.
     console.log('Received event:', JSON.stringify(event, null, 2));

     // If the caller is not an IAM user, do nothing.
     if (event.detail.userIdentity.type != 'IAMUser') {
         console.log('This call was not made by an IAM user!');
         context.done();
     } else {
         // Get the user name from the event.
         var userName = event.detail.userIdentity.userName;

     revokeAccess();

     // Revoke IAM access by attaching a Deny policy to the unauthorized
     // IAM user. If the IAM user already has more than the allowed number
     // of managed policies attached, add an inline policy to
     // deny access.
     function revokeAccess() {
         iam.attachUserPolicy(
             {UserName: userName, PolicyArn: policyArn},
             function(error, data) {
                 if (error) {
                     if (error.code == 'LimitExceeded') {
                         revokeAccessByInlinePolicy();
                     } else {
                         console.log(error);
                     }
                 } else {
                     console.log('Revoked IAM access for IAM user ' + userName);
                     context.done(); 
                 }
             }
         );
     }

     // Revoke IAM access by adding an inline policy.
     function revokeAccessByInlinePolicy() {
         var policyDocument =
             '{' +
                 '"Version": "2012-10-17",' +
                 '"Statement": [' +
                     '{' +
                         '"Effect": "Deny",' +
                         '"Action": "iam:*",' +
                         '"Resource": "*"' +
                     '}' +
                 ']' +
             '}';

         iam.putUserPolicy(
             {UserName: userName, PolicyName: 'DenyIAM', PolicyDocument: policyDocument},
             function(error, data) {
                 if (error) {
                     console.log(error);
                     context.fail('Failed to add inline DenyIAM policy!');
                 } else {
                     console.log('Revoked access via inline policy for IAM user ' + userName);
                     context.done(); 
                 }
             }
         );
     }
}